var n=`<svg
  width="48"
  height="50"
  viewBox="0 0 48 50"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g transform="translate(0, 24)">
    <title>earrings - stud</title>
    <circle
      cx="25"
      cy="4"
      r="4"
      fill="#F4D150"
    />
    <circle
      cx="26"
      cy="3"
      r="1"
      fill="#FFEDEF"
    />
  </g>
</svg>`;export{n as default};
