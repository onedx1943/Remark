var n=`<svg
  width="240"
  height="200"
  viewBox="0 0 240 200"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g transform="translate(-30, -12)">
    <title>tops - funny</title>
    <path
      d="M140 56C154.667 55.3333 180.4 47.2 166 20"
      stroke="black"
      stroke-width="4"
    />
    <path
      d="M114 54C128.667 53.3333 154.4 45.2 140 18"
      stroke="black"
      stroke-width="4"
    />
    <path
      d="M78 65C92.6667 64.3333 118.4 56.2 104 29"
      stroke="black"
      stroke-width="4"
    />
  </g>
</svg>`;export{n as default};
