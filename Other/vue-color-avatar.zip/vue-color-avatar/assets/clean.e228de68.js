var n=`<svg
  width="240"
  height="200"
  viewBox="0 0 240 200"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g transform="translate(-35, 40)">
    <title>tops - clean</title>
    <ellipse
      cx="147.854"
      cy="58.1803"
      rx="6.85759"
      ry="18.4393"
      transform="rotate(117 147.854 58.1803)"
      fill="#FCFDFF"
    />
  </g>
</svg>`;export{n as default};
