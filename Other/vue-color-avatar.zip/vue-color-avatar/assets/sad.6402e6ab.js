var n=`<svg
  width="64"
  height="64"
  viewBox="0 0 64 64"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g transform="translate(90, 160)">
    <title>mouth - sad</title>
    <path
      d="M13 46C14.7153 38.0427 21.0708 21.2329 32.7708 17.6522C44.4708 14.0714 50.4653 26.1068 52 32.5721"
      stroke="black"
      stroke-width="4"
    />
  </g>
</svg>`;export{n as default};
